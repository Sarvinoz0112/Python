import psycopg2
from datetime import datetime
from decimal import Decimal

# PostgreSQL database connection parameters
DB_PARAMS = {
    'dbname': 'postgres',
    'user': 'postgres',
    'password': 'sarvinoz2005',
    'host': 'localhost',
    'port': '5432'
}

def connect_db():
    """Establish a connection to the PostgreSQL database."""
    try:
        conn = psycopg2.connect(**DB_PARAMS)
        return conn
    except Exception as ex:
        print(f"An error occurred: {ex}")
        return None

def create_tables():
    """Create the necessary tables in the database."""
    conn = connect_db()
    if conn is None:
        return

    cur = conn.cursor()

    # Create users table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255),
        phone VARCHAR(15),
        password VARCHAR(255),
        card_number VARCHAR(16),
        card_balance DECIMAL(10, 2)
    )
    """)

    # Create powerbanks table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS powerbanks (
        id SERIAL PRIMARY KEY,
        active BOOLEAN DEFAULT FALSE,
        user_id INTEGER REFERENCES users(id),
        start_time TIMESTAMP
    )
    """)

    conn.commit()
    cur.close()
    conn.close()

def initialize_powerbanks():
    """Initialize the powerbanks in the database."""
    conn = connect_db()
    if conn is None:
        return

    cur = conn.cursor()

    # Insert 10 inactive powerbanks
    for _ in range(10):
        cur.execute("""
        INSERT INTO powerbanks (active)
        VALUES (FALSE)
        """)

    conn.commit()
    cur.close()
    conn.close()

def register_user(name, phone, password, confirm_password, card_number, card_balance):
    """Register a new user."""
    if password != confirm_password:
        print("Passwords do not match.")
        return

    if len(card_number) != 16 or not card_number.isdigit():
        print("Invalid card number. It must be 16 digits.")
        return

    conn = connect_db()
    if conn is None:
        return

    cur = conn.cursor()

    cur.execute("""
    INSERT INTO users (name, phone, password, card_number, card_balance)
    VALUES (%s, %s, %s, %s, %s)
    """, (name, phone, password, card_number, card_balance))

    conn.commit()
    cur.close()
    conn.close()
    print("User registered successfully.")

def login_user(phone, password):
    """Authenticate a user."""
    conn = connect_db()
    if conn is None:
        return None

    cur = conn.cursor()

    cur.execute("""
    SELECT id, name, card_balance FROM users WHERE phone = %s AND password = %s
    """, (phone, password))
    
    user = cur.fetchone()
    cur.close()
    conn.close()

    return user

def take_powerbank(user_id, hours):
    """Allow a user to rent a powerbank."""
    conn = connect_db()
    if conn is None:
        return

    cur = conn.cursor()

    cur.execute("""
    SELECT id FROM powerbanks WHERE active = FALSE LIMIT 1
    """)
    powerbank = cur.fetchone()

    if powerbank:
        powerbank_id = powerbank[0]
        cur.execute("""
        UPDATE powerbanks
        SET active = TRUE, user_id = %s, start_time = %s
        WHERE id = %s
        """, (user_id, datetime.now(), powerbank_id))
        
        conn.commit()
        print(f"Powerbank {powerbank_id} activated for {hours} hours.")
    else:
        print("Sorry, we don't have any available powerbanks at the moment. You can collect a powerbank from another location.")

    cur.close()
    conn.close()

def return_powerbank(user_id, powerbank_id):
    """Allow a user to return a powerbank and calculate charges."""
    conn = connect_db()
    if conn is None:
        return

    cur = conn.cursor()

    cur.execute("""
    SELECT start_time FROM powerbanks WHERE id = %s AND user_id = %s AND active = TRUE
    """, (powerbank_id, user_id))
    
    powerbank = cur.fetchone()

    if powerbank:
        start_time = powerbank[0]
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 3600  # convert seconds to hours
        rate_per_hour = Decimal('5.00')
        amount_due = Decimal(duration) * rate_per_hour

        cur.execute("""
        SELECT card_balance FROM users WHERE id = %s
        """, (user_id,))
        balance = cur.fetchone()[0]

        if balance >= amount_due:
            new_balance = balance - amount_due
            cur.execute("""
            UPDATE users
            SET card_balance = %s
            WHERE id = %s
            """, (new_balance, user_id))
            
            cur.execute("""
            UPDATE powerbanks
            SET active = FALSE, user_id = NULL, start_time = NULL
            WHERE id = %s
            """, (powerbank_id,))
            
            conn.commit()
            print(f"Powerbank {powerbank_id} returned. Total charge: ${amount_due:.2f}. Remaining balance: ${new_balance:.2f}")
        else:
            print(f"Insufficient balance. Amount due: ${amount_due:.2f}, but your balance is only ${balance:.2f}.")
    else:
        print(f"Powerbank with ID {powerbank_id} is not rented by you or does not exist.")

    cur.close()
    conn.close()

def auth_menu():
    """Display the authentication menu."""
    while True:
        print("\nAuth Menu:")
        print("1. Register")
        print("2. Login")
        print("3. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            name = input("Enter your name: ")
            phone = input("Enter your phone number: ")
            password = input("Enter your password: ")
            confirm_password = input("Confirm your password: ")
            card_number = input("Enter your 16-digit card number: ")
            card_balance = Decimal(input("Enter your card balance: "))
            register_user(name, phone, password, confirm_password, card_number, card_balance)
        elif choice == '2':
            phone = input("Enter your phone number: ")
            password = input("Enter your password: ")
            user = login_user(phone, password)
            if user:
                print(f"Welcome, {user[1]}!")
                user_menu(user[0])
            else:
                print("Invalid credentials.")
        elif choice == '3':
            break
        else:
            print("Invalid choice. Please try again.")

def user_menu(user_id):
    """Display the user menu."""
    while True:
        print("\nUser Menu:")
        print("1. Take powerbank")
        print("2. Return powerbank")
        print("3. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            hours = int(input("Enter the number of hours you want to rent the powerbank (per hour: 5.00): "))
            take_powerbank(user_id, hours)
        elif choice == '2':
            powerbank_id = int(input("Enter the number of the powerbank you want to return: "))
            return_powerbank(user_id, powerbank_id)
        elif choice == '3':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    create_tables()
    initialize_powerbanks()
    auth_menu()
