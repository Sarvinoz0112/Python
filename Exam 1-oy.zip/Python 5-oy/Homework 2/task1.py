'''Kontekst Menejeri'''
import psycopg2
from contextlib import contextmanager

@contextmanager
def get_db_connection():
    conn = psycopg2.connect(
        dbname='your_database',
        user='your_username',
        password='your_password',
        host='localhost'
    )
    try:
        yield conn
    finally:
        conn.close()

#-----------------------------------------------------------------------

'''Class'''
class Database:
    def __init__(self, dbname, user, password, host='localhost'):
        self.dbname = dbname #your database
        self.user = user #your username
        self.password = password #your password
        self.host = host
    
    @contextmanager
    def get_connection(self):
        conn = psycopg2.connect(
            dbname=self.dbname,
            user=self.user,
            password=self.password,
            host=self.host
        )
        try:
            yield conn
        finally:
            conn.close()

    def execute_query(self, query, params=None):
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                conn.commit()

    def fetch_results(self, query, params=None):
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                return cursor.fetchall()

#-----------------------------------------------------------------------

'''Generatorlar'''
def fetch_large_dataset(query, params=None):
    with Database('database', 'username', 'password').get_connection() as conn: #your database, your username, your password
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            while True:
                record = cursor.fetchone()
                if record is None:
                    break
                yield record
