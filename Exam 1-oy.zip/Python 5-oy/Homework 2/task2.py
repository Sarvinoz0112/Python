import psycopg2
from psycopg2 import sql
from contextlib import contextmanager
import hashlib
import datetime
from database_config import DATABASE

PREDEFINED_PASSWORDS = {
    'developer@example.com': 'developer_password',
    'admin@example.com': 'admin_password'
}

def hash_password(password):
    '''Hash the password using SHA-256.'''
    return hashlib.sha256(password.encode()).hexdigest()

@contextmanager
def get_db_connection():
    '''Context manager to handle database connection.'''
    conn = psycopg2.connect(**DATABASE)
    try:
        yield conn
    finally:
        conn.close()

class AuthService:
    '''Handles user authentication and registration.'''
    
    def __init__(self):
        '''Set up predefined users in the database.'''
        self.setup_predefined_users()

    def setup_predefined_users(self):
        '''Insert predefined users into the database.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                for email, password in PREDEFINED_PASSWORDS.items():
                    hashed_password = hash_password(password)
                    cursor.execute(
                        "INSERT INTO users (first_name, last_name, email, gender, birthday, password, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s) ON CONFLICT (email) DO NOTHING",
                        ('Default', 'User', email, 'male' if email == 'developer@example.com' else 'female', '2000-01-01', hashed_password, datetime.datetime.now())
                    )
                    conn.commit()

    def register(self, first_name, last_name, email, gender, birthday, password, confirm_password):
        '''Register a new user if passwords match.'''
        if password != confirm_password:
            print("Passwords do not match!")
            return
        hashed_password = hash_password(password)
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO users (first_name, last_name, email, gender, birthday, password, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (first_name, last_name, email, gender, birthday, hashed_password, datetime.datetime.now())
                )
                conn.commit()
                print("User registered successfully!")

    def login(self, email, password):
        '''Authenticate user and return user data if valid.'''
        hashed_password = hash_password(password)
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT id, first_name, last_name, email, gender, birthday FROM users WHERE email=%s AND password=%s",
                    (email, hashed_password)
                )
                user = cursor.fetchone()
                if user:
                    print(f"Welcome {user[1]} {user[2]}!")
                    return user
                else:
                    print("Invalid email or password")
                    return None

class DeveloperMenu:
    '''Menu functions for DEVELOPER role.'''
    def create_table():
        '''Create a new table with specified columns.'''
        table_name = input("Table name: ")
        columns = input("Columns (format: col1 TYPE, col2 TYPE...): ").split(', ')
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                columns_def = ', '.join(columns)
                query = sql.SQL("CREATE TABLE {table} ({columns})").format(
                    table=sql.Identifier(table_name),
                    columns=sql.SQL(columns_def)
                )
                cursor.execute(query)
                conn.commit()
                print(f"Table '{table_name}' created successfully!")

    def add_column():
        '''Add a column to an existing table.'''
        table_name = input("Table name: ")
        column_name = input("Column name: ")
        data_type = input("Data type: ")
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = sql.SQL("ALTER TABLE {table} ADD COLUMN {column} {type}").format(
                    table=sql.Identifier(table_name), #sql.Identifier is a crucial tool in the psycopg2 library for safely constructing SQL queries involving dynamic table and column names.
                    column=sql.Identifier(column_name),
                    type=sql.SQL(data_type)
                )
                cursor.execute(query)
                conn.commit()
                print(f"Column '{column_name}' added to table '{table_name}'.")

    def remove_column():
        '''Remove a column from an existing table.'''
        table_name = input("Table name: ")
        column_name = input("Column name: ")
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = sql.SQL("ALTER TABLE {table} DROP COLUMN {column}").format(
                    table=sql.Identifier(table_name), #sql.Identifier is a crucial tool in the psycopg2 library for safely constructing SQL queries involving dynamic table and column names.
                    column=sql.Identifier(column_name)
                )
                cursor.execute(query)
                conn.commit()
                print(f"Column '{column_name}' removed from table '{table_name}'.")

    def change_column_data_type():
        '''Change the data type of a column in a table.'''
        table_name = input("Table name: ")
        column_name = input("Column name: ")
        new_data_type = input("New data type: ")
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = sql.SQL("ALTER TABLE {table} ALTER COLUMN {column} TYPE {type}").format(
                    table=sql.Identifier(table_name), #sql.Identifier is a crucial tool in the psycopg2 library for safely constructing SQL queries involving dynamic table and column names.
                    column=sql.Identifier(column_name),
                    type=sql.SQL(new_data_type)
                )
                cursor.execute(query)
                conn.commit()
                print(f"Column '{column_name}' data type changed to '{new_data_type}' in table '{table_name}'.")

    def delete_table():
        '''Delete an existing table.'''
        table_name = input("Table name: ")
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = sql.SQL("DROP TABLE {table}").format(
                    table=sql.Identifier(table_name) #sql.Identifier is a crucial tool in the psycopg2 library for safely constructing SQL queries involving dynamic table and column names.
                )
                cursor.execute(query)
                conn.commit()
                print(f"Table '{table_name}' deleted successfully!")

    def show_all_tables():
        '''Show all tables in the public schema.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")
                tables = cursor.fetchall()
                if tables:
                    print("Tables:")
                    for table in tables:
                        print(f"- {table[0]}")
                else:
                    print("No tables found.")

class AdminMenu:
    '''Menu functions for ADMIN role.'''
    def show_all_users():
        '''Show all registered users.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, first_name, last_name, email FROM users")
                users = cursor.fetchall()
                if users:
                    print("All Users:")
                    for user in users:
                        print(f"ID: {user[0]}, Name: {user[1]} {user[2]}, Email: {user[3]}")
                else:
                    print("No users found.")

    def show_all_female_users():
        '''Show all female users.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, first_name, last_name, email FROM users WHERE gender='female'")
                users = cursor.fetchall()
                if users:
                    print("Female Users:")
                    for user in users:
                        print(f"ID: {user[0]}, Name: {user[1]} {user[2]}, Email: {user[3]}")
                else:
                    print("No female users found.")

    def show_all_male_users():
        '''Show all male users.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, first_name, last_name, email FROM users WHERE gender='male'")
                users = cursor.fetchall()
                if users:
                    print("Male Users:")
                    for user in users:
                        print(f"ID: {user[0]}, Name: {user[1]} {user[2]}, Email: {user[3]}")
                else:
                    print("No male users found.")

    def delete_user():
        '''Delete a user by their ID.'''
        while True:
            try:
                user_id = int(input("User ID to delete: "))
                with get_db_connection() as conn:
                    with conn.cursor() as cursor:
                        cursor.execute("DELETE FROM users WHERE id=%s", (user_id,))
                        conn.commit()
                        print(f"User with ID '{user_id}' deleted.")
                break
            except ValueError:
                print("Invalid ID. Please enter a numeric value.")

class UserMenu:
    '''Menu functions for USER role.'''
    
    def show_all_my_data(user_id):
        '''Show all data for the currently logged-in user.'''
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT first_name, last_name, email, gender, birthday FROM users WHERE id=%s", (user_id,))
                user = cursor.fetchone()
                if user:
                    print("Your Data:")
                    print(f"Name: {user[0]} {user[1]}")
                    print(f"Email: {user[2]}")
                    print(f"Gender: {user[3]}")
                    print(f"Birthday: {user[4]}")
                else:
                    print("User not found.")

def main():
    '''Main function to run the application.'''
    auth_service = AuthService()
    while True:
        print("\nAUTH MENU:")
        print("1. Login")
        print("2. Register")
        print("3. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            email = input("Email: ")
            password = input("Password: ")
            user = auth_service.login(email, password)
            if user:
                user_role = 'DEVELOPER' if email == 'developer@example.com' else ('ADMIN' if email == 'admin@example.com' else 'USER')

                if user_role == 'DEVELOPER':
                    while True:
                        print("\nDEVELOPER MENU:")
                        print("1. Create Table")
                        print("2. Add Column to Table")
                        print("3. Remove Column from Table")
                        print("4. Change Column Data Type")
                        print("5. Delete Table")
                        print("6. Show All Tables")
                        print("7. Logout")

                        dev_choice = input("Choose an option: ")

                        if dev_choice == '1':
                            DeveloperMenu.create_table()
                        elif dev_choice == '2':
                            DeveloperMenu.add_column()
                        elif dev_choice == '3':
                            DeveloperMenu.remove_column()
                        elif dev_choice == '4':
                            DeveloperMenu.change_column_data_type()
                        elif dev_choice == '5':
                            DeveloperMenu.delete_table()
                        elif dev_choice == '6':
                            DeveloperMenu.show_all_tables()
                        elif dev_choice == '7':
                            break
                        else:
                            print("Invalid option!")

                elif user_role == 'ADMIN':
                    while True:
                        print("\nADMIN MENU:")
                        print("1. Show All Users")
                        print("2. Show All Female Users")
                        print("3. Show All Male Users")
                        print("4. Delete User")
                        print("5. Logout")

                        admin_choice = input("Choose an option: ")

                        if admin_choice == '1':
                            AdminMenu.show_all_users()
                        elif admin_choice == '2':
                            AdminMenu.show_all_female_users()
                        elif admin_choice == '3':
                            AdminMenu.show_all_male_users()
                        elif admin_choice == '4':
                            AdminMenu.delete_user()
                        elif admin_choice == '5':
                            break
                        else:
                            print("Invalid option!")

                elif user_role == 'USER':
                    while True:
                        print("\nUSER MENU:")
                        print("1. Show All My Data")
                        print("2. Logout")

                        user_choice = input("Choose an option: ")

                        if user_choice == '1':
                            UserMenu.show_all_my_data(user[0])
                        elif user_choice == '2':
                            break
                        else:
                            print("Invalid option!")

        elif choice == '2':
            first_name = input("First Name: ")
            last_name = input("Last Name: ")
            email = input("Email: ")
            gender = input("Gender (male/female): ")
            birthday = input("Birthday (YYYY-MM-DD): ")
            password = input("Password: ")
            confirm_password = input("Confirm Password: ")
            auth_service.register(first_name, last_name, email, gender, birthday, password, confirm_password)

        elif choice == '3':
            break

        else:
            print("Invalid option!")

if __name__ == "__main__":
    main()
