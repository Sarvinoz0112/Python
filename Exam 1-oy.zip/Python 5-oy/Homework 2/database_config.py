DATABASE = {
    'dbname': 'postgres',
    'user': 'postgres',
    'password': 'sarvinoz2005',
    'host': 'localhost'
}
